Master_IP_address = "localhost"  # The IP address of your Master Computer
Master_Port = "12345" # can be a random number, but this Port number must not be occupied by the other Program

